?package(roswell):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="roswell" command="/usr/bin/roswell"
