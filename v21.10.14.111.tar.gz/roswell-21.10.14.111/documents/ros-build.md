
ros-build - Shortcut to "ros dump executable"
# synopsis

**ros [options] build** <file>

Equivalent to calling `ros dump executable <file>`.

<!-- # subcommands -->

<!-- somecommand -->
 
<!--   : description. end with a period. -->

# description

<!-- # options -->
<!--  -->
<!-- # Environmental Variables -->

# SEE ALSO
_ros_(1)
