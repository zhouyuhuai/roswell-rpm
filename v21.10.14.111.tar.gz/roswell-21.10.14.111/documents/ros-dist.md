
ros-dist - 
# synopsis

**ros [options] dist** args...

<!-- # subcommands -->

<!-- somecommand -->
 
<!--   : description. end with a period. -->

# description

<!-- # options -->
<!--  -->
<!-- # Environmental Variables -->

# SEE ALSO
_ros_(1)
