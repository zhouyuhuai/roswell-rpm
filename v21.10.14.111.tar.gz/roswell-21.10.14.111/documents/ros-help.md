ros-help - Show Command help

# Synopsis

**ros help** [subcommand or topics]

<!-- # subcommands -->

<!-- somecommand -->
<!-- :description. end with a period. -->

# Description

**ros help** shows description of subcommand or topics

<!-- # options -->
<!--  -->
<!-- # Environmental Variables -->

# SEE ALSO
_sbcl_(1), _ros_(1)

