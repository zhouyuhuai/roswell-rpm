
ros-run - start a REPL
# Synopsis

**ros [options] run**


<!-- # subcommands -->

<!-- somecommand -->
 
<!--   : description. end with a period. -->

# Description

Processes the given options and start a REPL using the currently effective
lisp implementation set by _ros-use_(1).

<!-- # options -->
<!--  -->
<!-- # Environmental Variables -->

# SEE ALSO
_ros_(1)
