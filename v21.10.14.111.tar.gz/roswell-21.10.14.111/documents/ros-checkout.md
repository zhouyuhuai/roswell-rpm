
ros-checkout - 
# synopsis

**ros [options] checkout** args...

<!-- # subcommands -->

<!-- somecommand -->
 
<!--   : description. end with a period. -->

# description

to enable this command ros install roswell/ql-checkout is needed.

<!-- # options -->
<!--  -->
<!-- # Environmental Variables -->

# SEE ALSO
_ros_(1)
