ros-serve - start lisp server

# Synopsis

**ros [options for roswell ... ] serve** protocol [options for the protocol ...] ...

<!-- # subcommands -->
<!-- somecommand -->
 
<!--   : description. end with a period. -->

# description

`ros-serve` start lisp and wait for clients to connect to the lisp.

# swank protocol options

`--port port`

  : Listen port would be `port` instead of the default port 4005.

`--interface interface`

  : limit interface for listen. default is `localhost` so there would be no limitation.

<!-- # options -->
<!--  -->
<!-- # Environmental Variables -->

# SEE ALSO
_ros_(1) _ros-client_(1)
