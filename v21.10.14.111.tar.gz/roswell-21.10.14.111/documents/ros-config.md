
ros-config - get and set options
# Synopsis

**ros [options] config** [SUBCOMMAND ARGS...]

# Description

Without any arguments, it shows all variables and it's value.

show TARGET

  : show TARGET.


set TARGET VALUE

  : set the VALUE to the TARGET.

<!-- # options -->
<!--  -->
<!-- # Environmental Variables -->

# SEE ALSO
_ros_(1)
