
ros-emacs - launch Emacs with Slime
# Synopsis

**ros emacs** [ARGS...]

<!-- # subcommands -->

<!-- somecommand -->
 
<!--   : description. end with a period. -->

# Description

Launches Emacs with a Slime(https://common-lisp.net/project/slime/) buffer opened, which is connected to the back-end lisp implementation of roswell.
Additional arguments are passed to emacs.

<!-- # options -->
<!--  -->
<!-- # Environmental Variables -->

# SEE ALSO
_ros_(1), _emacs_(1)
